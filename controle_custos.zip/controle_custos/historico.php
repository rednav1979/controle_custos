<?php
session_start();
include('verifica_login.php');
?>	
<!DOCTYPE html>
<html>



 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
</head>



<img src=css/logo.png><br>
Hoje, 
<script Language="JavaScript">
<!--
mydate = new Date();
myday = mydate.getDay();
mymonth = mydate.getMonth();
myweekday= mydate.getDate();
weekday= myweekday; 
myear = mydate.getFullYear();

if(myday == 0)
day = " Domingo, " 

else if(myday == 1)
day = " Segunda - Feira, " 

else if(myday == 2)
day = " Terça - Feira, " 

else if(myday == 3)
day = " Quarta - Feira, " 

else if(myday == 4)
day = " Quinta - Feira, " 

else if(myday == 5)
day = " Sexta - Feira, " 

else if(myday == 6)
day = " Sábado, " 

if(mymonth == 0)
month = "Janeiro " 

else if(mymonth ==1)
month = "Fevereiro " 

else if(mymonth ==2)
month = "Março " 

else if(mymonth ==3)
month = "Abril " 

else if(mymonth ==4)
month = "Maio " 

else if(mymonth ==5)
month = "Junho " 

else if(mymonth ==6)
month = "Julho " 

else if(mymonth ==7)
month = "Agosto " 

else if(mymonth ==8)
month = "Setembro " 

else if(mymonth ==9)
month = "Outubro " 

else if(mymonth ==10)
month = "Novembro " 

else if(mymonth ==11)
month = "Dezembro " 

document.write("<font face=arial, size=2>"+ day);
document.write(myweekday+" de "+month+ "</font>");
document.write(myear);
// -->
</script>

<body>

    <section class="hero is-success is-fullheight">
	
        
            <div class="container has-text-centered">			
                
                    <h1 class="title has-text-grey">MENU DE ACESSO</h1>
					<h2 class="title has-text-grey"><font size=4>[Tecnologia da Informação]</font></h2>                   
                    <div class="box">
					<font color=red size=4> HISTORICO DE REGISTROS:</font>
                    <font size=2>
					
					

					
					<?php 
   include "sql_t.i.php";//conexão com o banco de dados
   
   @mysql_select_db($db);//selecione o banco de dados
    $id_fixo = $_GET['id'];
	
	$sqltudo = mysql_query("select  * FROM controle_custos_historico where D_E_L_E_T_E IS NULL and id_historico=('$id_fixo')")  or die(mysql_error());
           
           $colunas = mysql_num_rows($sqltudo);

	   print'<br>';	

	   print'<br>';   	
       print'<table border="1"   bordercolor="#00BFFF" >';
	   print'<tr>';
	   print'<td><b>ID</td>';	   
	   print'<td><b>D</td>';
	   print'<td><b>A</td>';	   
	   print'<td><b>HISTORICO</td>';  
	   print'<td><b>NOME</td>';	   
	   print'<td><b>DESCRICAO</td>';
	   print'<td><b>CUSTO</td>';
	   print'<td><b>FORNECEDOR</td>';
	   print'<td><b>CONTATO</td>';
	   print'<td><b>OBRA</td>';	   	   
	   print'<td><b>CONTRATO</td>';
	   
	   print'</tr></b>';
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
           $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
           $nome = @mysql_result($sqltudo, $j, "nome");
           $descricao = @mysql_result($sqltudo, $j, "descricao");
           $fornecedor = @mysql_result($sqltudo, $j, "fornecedor");
           $contato = @mysql_result($sqltudo, $j, "contato");           		   
		   $obra = @mysql_result($sqltudo, $j, "obra");  
		   $valor = @mysql_result($sqltudo, $j, "valor");  
		   $url_contrato = @mysql_result($sqltudo, $j, "url_contrato");
		   
		  
	   /*print '<table border=1>';/*monta a tabela de eventos*/

	       print'<tr>';	       
		   print '<td>'.$id.'</td>';	       
		   print '<td><a href="delete.php?id='.$id.'"><img src=images/bolinha_vermelha.png width=25 height=25></a></td>';  
		   print '<td><a href="listar_pesquisa_update.php?id='.$id.'"><img src=images/relogio.jpg width=25 height=25"></a></td>';	   	   		   
		   print '<td><a href="historico.php?id='.$id.'"><img src=images/historico.jpg width=40 height=40></a>';		   
	   // INCLUI O NUMERO DE HISTORICOS AO LADO DO ICONE DE HISTORICO
		   include "sql_t.i.php";//conexão com o banco de dados   
           @mysql_select_db($db);//selecione o banco de dados
           
		   $colaborador_old='';
		   $sqltudo2 = mysql_query("SELECT count(nome)as num_hist,nome,id_historico FROM controle_custos_historico where id_historico = $id and D_E_L_E_T_E IS NULL order by id desc limit 1")  or die(mysql_error());
           $colunas2 = mysql_num_rows($sqltudo2);		  	   
           for($x = 0; $x < $colunas2; $x++){/*caso no mesmo dia tenha mais eventos continua imprimindo */           
           $id_historico = @mysql_result($sqltudo2, $x, "id_historico"); 		   
		   $num_historico = @mysql_result($sqltudo2, $x, "num_hist"); 
		   print $num_historico;	   	   		   		   
		   //print $id_historico;	   	   		   		   
	       print'</td>';	   
           }	   
		   //FIM DA INCLUSAO 
		   print '<td >'.$nome.'</td>';	   
		   print '<td>'.$descricao.'</td>';
		   print '<td>'.$valor.'</td>';
		   print '<td>'.$fornecedor.'</td>';		   
		   print '<td>'.$contato.'</td>';
		   print '<td>'.$obra.'</td>';
		   
	  
	   // VERIFICA SE TEM TERMO E SE O EQUIPAMENTO NÃO É DA SEDE PARA COLOCAR O BOTAO DE UPLOAD
	   if ($url_contrato == ""){  
		       
				print ' <td><form method="post" action="file_upload.php?id='.$id.'" enctype="multipart/form-data">
					<label>Arquivo:</label>
					<input type="file" name="arquivo" />
					<input type="submit" value="Enviar" />
		     		</form></td>';
		}else{	
			print '<td><a href="uploads_contrato/'.$url_contrato.'"target="_blank"><img src="images/bolinha_verde.png" width=30 height=30></a>';	
		}
	   print '</tr>';	
           }
	   print'</table>';
		print '<br>';
		print '<hr>';
		

?>					<a href="listar_pesquisa.php">[V O L T A R  ]</a>
                    </div>
                </div>
            </div>
        </div>
		
    </section>
	
	<br>

<br>


</body>

</html>


